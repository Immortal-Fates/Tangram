#ifndef _SOLVE_H_
#define SOLVE_H


#endif // !_SOLVE_H_
